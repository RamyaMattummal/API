﻿namespace OneSpan.Dto
{
    public class PackageDto
    {
        public List<Result> Results { get; set; }
        public int Count { get; set; }
    }
    public class Result
    {
        public bool Autocomplete { get; set; }
        public string Consent { get; set; }
        public string Description { get; set; }
        public List<Document> Documents { get; set; }
        public string Due { get; set; }
        public string EmailMessage { get; set; }
        public string Language { get; set; }
        public List<Role> Roles { get; set; }
        public Sender Sender { get; set; }
        public Settings Settings { get; set; }
        // Add other properties as needed
    }

    public class Document
    {
        public string Status { get; set; }
        public bool ExternalSigned { get; set; }
        public string Description { get; set; }
        // Add other properties as needed
    }

    public class Role
    {
        public string Id { get; set; }
        public bool Locked { get; set; }
        // Add other properties as needed
    }

    public class Sender
    {
        public string Company { get; set; }
        public string Email { get; set; }
        // Add other properties as needed
    }

    public class Settings
    {
        public Ceremony Ceremony { get; set; }
        // Add other properties as needed
    }

    public class Ceremony
    {
        public bool DeclineButton { get; set; }
        // Add other properties as needed
    }
}
