﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OneSpan.Models;

public partial class OneSpanContext : DbContext
{
    public OneSpanContext()
    {
    }

    public OneSpanContext(DbContextOptions<OneSpanContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Package> Packages { get; set; }

    public virtual DbSet<SpanLog> SpanLogs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(Database.GetConnectionString());
        }
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Package>(entity =>
        {
            entity.HasKey(e => e.Packageid).HasName("PK__Package__AA8A5400F9F177F9");

            entity.ToTable("Package");

            entity.Property(e => e.Packageid)
                .ValueGeneratedNever()
                .HasColumnName("packageid");
            entity.Property(e => e.Logdate)
                .HasColumnType("datetime")
                .HasColumnName("logdate");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        modelBuilder.Entity<SpanLog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__SpanLog__3213E83F5C02FCF1");

            entity.ToTable("SpanLog");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Logdate)
                .HasColumnType("datetime")
                .HasColumnName("logdate");
            entity.Property(e => e.Packageid).HasColumnName("packageid");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
