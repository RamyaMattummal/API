using Microsoft.EntityFrameworkCore;
using OneSpan.Dto;
using OneSpan.Interfaces;
using OneSpan.Models;
using OneSpan.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Configuration.AddJsonFile("appsettings.json");
builder.Logging.AddConfiguration(builder.Configuration.GetSection("Logging"));
builder.Logging.AddConsole();
builder.Logging.AddDebug();
builder.Services.AddControllers();
builder.Services.AddHttpClient();
// Add services to the container.
builder.Services.AddScoped<IDocumentService, DocumentService>();
builder.Services.Configure<OneSpanSettings>(builder.Configuration.GetSection("OneSpan"));
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<OneSpanContext>(options =>
{
    options.UseSqlServer("name=ConnectionStrings:OneSpanDbContext");
});

var app = builder.Build();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
