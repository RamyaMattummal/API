﻿using System.Reflection.Metadata;

namespace OneSpan.Interfaces
{
    public interface IDocumentService
    {
        Task<string> GetPackageStatusAsync(int packageId);
        Task<string> GetAllPackages();
        string CreatePackage();

        // void AddDocumentsToPackage(string packageId, List<Document> documents);

        // void UpdatePackage(string packageId, PackageUpdateRequest updateRequest);
    }
}
