﻿using System;
using System.Collections.Generic;

namespace OneSpan.Models;

public partial class Package
{
    public int Packageid { get; set; }

    public string? Status { get; set; }

    public DateTime? Logdate { get; set; }
}
