﻿namespace OneSpan.Dto
{
    public class ApiResponse
    {
        public List<object>? Results { get; set; }
        public int Count { get; set; }
    }
}


