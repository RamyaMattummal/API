﻿using Microsoft.AspNetCore.Mvc;
using OneSpan.Interfaces;
using System.Reflection.Metadata;

namespace OneSpan.Controllers
{
    [ApiController]
    [Route("api/documents")]
    public class DocumentController : ControllerBase
    {
        private readonly IDocumentService _documentService;
        private readonly ILogger<DocumentController> _logger;

        public DocumentController(IDocumentService documentService, ILogger<DocumentController> logger)
        {
            _documentService = documentService;
            _logger = logger;
        }

        [HttpGet("{packageId}/status")]
        public ActionResult<string> GetPackageStatus(int packageId)
        {
            _logger.LogInformation("This is a log message from the controller.");
            var status = _documentService.GetPackageStatusAsync(packageId);
            return Ok(status);
        }

        [HttpGet]
        public ActionResult<string> GetAllPackages()
        {
            _logger.LogInformation("This is a log message from the controller.");
            var status = _documentService.GetAllPackages();
            return Ok(status);
        }
        [HttpGet("CreatePackage")]
        public async Task<ActionResult<string>> CreatePackage()
        {
            _logger.LogInformation("This is a log message from the controller.");

            try
            {
                var status = await _documentService.CreatePackage();
                return Ok(status);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating the package.");
                return StatusCode(500, "Internal server error");
            }
        }

        //[HttpPost("{packageId}/documents")]
        //public ActionResult AddDocumentsToPackage(string packageId, [FromBody] List<Document> documents)
        //{
        //    _documentService.AddDocumentsToPackage(packageId, documents);
        //    return Ok();
        //}

        //[HttpPut("{packageId}")]
        //public ActionResult UpdatePackage(string packageId, [FromBody] PackageUpdateRequest updateRequest)
        //{
        //    _documentService.UpdatePackage(packageId, updateRequest);
        //    return Ok();
        //}
    }

}
