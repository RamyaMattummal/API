﻿using OneSpan.Interfaces;
using System.Reflection.Metadata;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using OneSpan.Dto;
using System.Net.Http.Headers;
using OneSpan.Models;
using Microsoft.EntityFrameworkCore;
using OneSpanSign.Sdk;
using OneSpanSign.Sdk.Builder;
using System;
using System.IO;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace OneSpan.Services
{
    public class DocumentService : IDocumentService
    {
        private readonly ILogger<DocumentService> _logger;
        private readonly HttpClient _oneSpanApiClient;
        private readonly string _apiBaseUrl;
        private readonly string _accessToken;
        private readonly OneSpanContext _dbContext;
        public DocumentService(HttpClient oneSpanApiClient,IHttpClientFactory httpClientFactory, IOptions<OneSpanSettings> oneSpanSettings, ILogger<DocumentService> logger, OneSpanContext dbContext)
        {
            _logger = logger;
            _oneSpanApiClient = httpClientFactory.CreateClient();
            _apiBaseUrl = oneSpanSettings.Value.ApiBaseUrl;
            _accessToken = oneSpanSettings.Value.AccessToken;
            _oneSpanApiClient.BaseAddress = new Uri(_apiBaseUrl);
            _dbContext = dbContext;
            // Set necessary headers, authentication, etc. for the OneSpan API
            // _oneSpanApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "YourAccessToken");
        }
        private void SetBearerToken()
        {
            // Check if the access token is not null or empty before setting it
            if (!string.IsNullOrEmpty(_accessToken))
            {
                _oneSpanApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _accessToken);
                _oneSpanApiClient.DefaultRequestHeaders.Add("accept", "application/json");
            }   
            else
            {
                _logger.LogWarning("Access token is not configured. Make sure to set the access token in your configuration.");
            }
        }

        public async Task<string> CreatePackage()
        {

            SetBearerToken();
            string requestBody = "{\"name\":\"TestPackage\"}";

            var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
            var response = await _oneSpanApiClient.PostAsync("/packages", content);
            if (response.IsSuccessStatusCode)
            {
                // Read the response content
                // Read response content
                string responseContent = await response.Content.ReadAsStringAsync();


                // Parse the JSON response content
                dynamic responseData = JObject.Parse(responseContent);

                // Extract the id field from the response
                string id = responseData.id;

                // Return the id extracted from the response
                return $"{id}";
            }
            else
            {
                return "Status of onespan package";
            }


            //string jsonString = "{\"name\":\"Package created from a template\",\"description\":\"\",\"emailMessage\":\"\",\"autocomplete\":true,\"settings\":{\"ceremony\":{\"inPerson\":false}},\"type\":\"PACKAGE\",\"visibility\":\"ACCOUNT\",\"due\":null,\"language\":\"en\"}";

            //StringContent jsonContent = new StringContent(jsonString, Encoding.UTF8, "application/json");

            //HttpClient myClient = new HttpClient();
            //myClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _accessToken);
            //myClient.DefaultRequestHeaders.Add("Accept", "application/json");

            //var response = myClient.PostAsync(new Uri(_apiBaseUrl+"api") + "/packages/WeS0GThlo_qItT76fwn2ebFnUPc=/clone", jsonContent).Result;

            //FileStream fs = File.OpenRead("./Document.pdf");
            //OssClient ossClient = new OssClient(_accessToken, _apiBaseUrl);
            //DocumentPackage superDuperPackage = PackageBuilder.NewPackageNamed("Test Package .NET").WithSettings(DocumentPackageSettingsBuilder.NewDocumentPackageSettings())
            //    .WithSigner(SignerBuilder.NewSignerWithEmail("signer.email@example.com")
            //    .WithFirstName("Signer First Name")
            //    .WithLastName("Signer Last Name")
            //    .WithCustomId("Signer"))
            //    .WithSigner(SignerBuilder.NewSignerWithEmail("your.email@example.com")
            //    .WithFirstName("Your First Name")
            //    .WithLastName("Your Last Name"))
            //    .WithDocument(DocumentBuilder.NewDocumentNamed("sampleAgreement")
            //    .FromStream(fs, DocumentType.PDF)
            //    .WithSignature(SignatureBuilder
            //        .SignatureFor("signer.email@example.com")
            //        .OnPage(0)
            //        .AtPosition(175, 165))
            //    .WithSignature(SignatureBuilder
            //        .SignatureFor("your.email@example.com")
            //        .OnPage(0)
            //        .AtPosition(550, 165))).Build();
            //if (superDuperPackage != null)
            //{
            //    PackageId packageId = ossClient.CreatePackageOneStep(superDuperPackage);
            //    ossClient.SendPackage(packageId);
            //        }
            //return "";
        }

        

       

        public async Task<string> GetAllPackages()
        {
            try
            {
                _logger.LogInformation("This is a log message from the DocumentService.");
                // Set Bearer token
                SetBearerToken();

                // Make a GET request to the OneSpan API to retrieve package status
                var response = await _oneSpanApiClient.GetAsync($"api/packages");

                if (response.IsSuccessStatusCode)
                {

                    // Assuming ApiResponse is the class representing the JSON structure
                    var apiResponse = await response.Content.ReadFromJsonAsync<ApiResponse>();

                    // Now you can access the data from the response
                    var results = apiResponse.Results;
                    var count = apiResponse.Count;

                    // Further processing or returning data as needed
                    return $"Retrieved {count} items";

                }
                else
                {
                    // Handle error scenarios, log, etc.
                    return $"Not able to retrieve packages";
                }
            }
            catch (Exception ex)
            {
               
                // Handle exceptions, log, etc.
                return $"An error occurred while retrieving status for OneSpan package with ID";
            }

        }
            public async Task<string> GetPackageStatusAsync(int packageId)
        {
            try
            {
                _logger.LogInformation("This is a log message from the DocumentService.");
                // Set Bearer token
                SetBearerToken();

                // Make a GET request to the OneSpan API to retrieve package status
                var response = await _oneSpanApiClient.GetAsync($"/packages/{packageId}/signingStatus");

                if (response.IsSuccessStatusCode)
                {
                    // Parse the response and return the status
                    var status = await response.Content.ReadAsStringAsync();
                    var package = new Package
                    {
                        Packageid = packageId,
                        Status = status,
                        Logdate = DateTime.UtcNow // Set the date as per your requirement
                    };

                    _dbContext.Packages.Add(package);
                    await _dbContext.SaveChangesAsync();

                    // Add entry to SpanLogTable
                    var spanLog = new SpanLog
                    {
                        Packageid = packageId,
                        Status = status,
                        Logdate = DateTime.UtcNow // Set the date as per your requirement
                    };

                    _dbContext.SpanLogs.Add(spanLog);
                    await _dbContext.SaveChangesAsync();
                    return $"Status of OneSpan package with ID {packageId} is {status}";

                }
                else
                {
                    // Handle error scenarios, log, etc.
                    return $"Failed to retrieve status for OneSpan package with ID {packageId}";
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"An error occurred while retrieving status for OneSpan package with ID { packageId}: { ex.Message}");

                // Handle exceptions, log, etc.
                return $"An error occurred while retrieving status for OneSpan package with ID {packageId}: {ex.Message}";
            }
        }


        //public void AddDocumentsToPackage(string packageId, List<Document> documents)
        //{
        //    // Logic to add documents to OneSpan package
        //    // You would replace this with actual OneSpan API calls
        //    Console.WriteLine($"Added {documents.Count} documents to OneSpan package with ID {packageId}");
        //}

        //public void UpdatePackage(string packageId, PackageUpdateRequest updateRequest)
        //{
        //    // Logic to update OneSpan package
        //    // You would replace this with actual OneSpan API calls
        //    Console.WriteLine($"Updated OneSpan package with ID {packageId}");
        //}


    }
}
