﻿using OneSpan.Interfaces;
using System.Reflection.Metadata;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using OneSpan.Dto;
using System.Net.Http.Headers;
using OneSpan.Models;
using Microsoft.EntityFrameworkCore;

namespace OneSpan.Services
{
    public class DocumentService : IDocumentService
    {
        private readonly ILogger<DocumentService> _logger;
        private readonly HttpClient _oneSpanApiClient;
        private readonly string _apiBaseUrl;
        private readonly string _accessToken;
        private readonly OneSpanContext _dbContext;
        public DocumentService(HttpClient oneSpanApiClient, IOptions<OneSpanSettings> oneSpanSettings, ILogger<DocumentService> logger, OneSpanContext dbContext)
        {
            _logger = logger;
            _oneSpanApiClient = oneSpanApiClient;
            _apiBaseUrl = oneSpanSettings.Value.ApiBaseUrl;
            _accessToken = oneSpanSettings.Value.AccessToken;
            _oneSpanApiClient.BaseAddress = new Uri(_apiBaseUrl);
            _dbContext = dbContext;
            // Set necessary headers, authentication, etc. for the OneSpan API
            // _oneSpanApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "YourAccessToken");
        }
        private void SetBearerToken()
        {
            // Check if the access token is not null or empty before setting it
            if (!string.IsNullOrEmpty(_accessToken))
            {
                _oneSpanApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);
            }
            else
            {
                _logger.LogWarning("Access token is not configured. Make sure to set the access token in your configuration.");
            }
        }
        public async Task<string> GetPackageStatusAsync(int packageId)
        {
            try
            {
                _logger.LogInformation("This is a log message from the DocumentService.");
                // Set Bearer token
                SetBearerToken();

                // Make a GET request to the OneSpan API to retrieve package status
                var response = await _oneSpanApiClient.GetAsync($"/packages/{packageId}/signingStatus");

                if (response.IsSuccessStatusCode)
                {
                    // Parse the response and return the status
                    var status = await response.Content.ReadAsStringAsync();
                    var package = new Package
                    {
                        Packageid = packageId,
                        Status = status,
                        Logdate = DateTime.UtcNow // Set the date as per your requirement
                    };

                    _dbContext.Packages.Add(package);
                    await _dbContext.SaveChangesAsync();

                    // Add entry to SpanLogTable
                    var spanLog = new SpanLog
                    {
                        Packageid = packageId,
                        Status = status,
                        Logdate = DateTime.UtcNow // Set the date as per your requirement
                    };

                    _dbContext.SpanLogs.Add(spanLog);
                    await _dbContext.SaveChangesAsync();
                    return $"Status of OneSpan package with ID {packageId} is {status}";

                }
                else
                {
                    // Handle error scenarios, log, etc.
                    return $"Failed to retrieve status for OneSpan package with ID {packageId}";
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"An error occurred while retrieving status for OneSpan package with ID { packageId}: { ex.Message}");

                // Handle exceptions, log, etc.
                return $"An error occurred while retrieving status for OneSpan package with ID {packageId}: {ex.Message}";
            }
        }


        //public void AddDocumentsToPackage(string packageId, List<Document> documents)
        //{
        //    // Logic to add documents to OneSpan package
        //    // You would replace this with actual OneSpan API calls
        //    Console.WriteLine($"Added {documents.Count} documents to OneSpan package with ID {packageId}");
        //}

        //public void UpdatePackage(string packageId, PackageUpdateRequest updateRequest)
        //{
        //    // Logic to update OneSpan package
        //    // You would replace this with actual OneSpan API calls
        //    Console.WriteLine($"Updated OneSpan package with ID {packageId}");
        //}


    }
}
