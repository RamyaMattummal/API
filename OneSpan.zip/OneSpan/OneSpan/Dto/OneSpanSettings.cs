﻿namespace OneSpan.Dto
{
    public class OneSpanSettings
    {
        public string ApiBaseUrl { get; set; }
        public string AccessToken { get; set; }
    }
}
